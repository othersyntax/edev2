<!DOCTYPE html>
<html>
<head>
    <title>Sistem eDE</title>
</head>
<body>
    <p>Assalammualaikum dan salam sejahtera,</p><br>
    <p>YBhg. Datuk Dr../YBhg. Dato'./YBrs. Dr./Tuan/Puan, <br></p>
    <h3>PEMAKLUMAN PENERIMAAN PERMOHONAN PROJEK BAHARU BP00600 TAHUN 2025</h3>
    <p>
        Sukacita dimaklumkan bahawa Unit Bajet RMK, Bahagian Pembangunan telah menerima permohonan peruntukan BP00600 daripada <strong>{{ $program}}</strong>.<br><br><br>
        Sekian, terima kasih.<br><br>
        <strong>“MALAYSIA MADANI”</strong><br><br>
        <strong>“BERKHIDMAT UNTUK NEGARA”</strong><br><br><br>
        Saya yang menjalankan amanah,<br>
        BAHAGIAN PEMBANGUNAN<br>
        KEMENTERIAN KESIHATAN MALAYSIA
    </p><br>
    <p><i><small>E-mel ini adalah janaan komputer. Tiada sebarang maklum balas diperlukan</small></i></p>
</body>
</html>

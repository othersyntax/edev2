@extends('layouts.main')
@section('title')
    Permohonan Baharu
@endsection
@section('custom-css')
    <!-- Sweet Alert -->
    <link href="{{ asset("/template/css/plugins/sweetalert/sweetalert.css") }}" rel="stylesheet">
    <link href="{{ asset("/template/css/plugins/datapicker/datepicker3.css") }}" rel="stylesheet">
    <link href="{{ asset('/template/css/plugins/footable/footable.core.css') }}" rel="stylesheet">
@endsection

@section('breadcrumb')
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-sm-4">
        <h2>Guna Baki</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Projek</a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Baharu</strong>
            </li>
        </ol>
    </div>
</div>
@endsection

@section('content')
<form action="/projek/baki/simpan-sedia-ada" method="post">
    @csrf
<div class="row">

    <div class="col-12">
        <div class="ibox">
            <div class="ibox-title">
                <h5>1. MAKLUMAT PROJEK YANG DISELENGGARA</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                    <a class="close-link">
                        <i class="fa fa-times"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <input type="text" class="form-control form-control-sm m-b-xs" id="filter2" placeholder="Cari projek">
                <table class="footable2 table table-stripped" data-page-size="10" data-filter=#filter2>
                    <thead>
                        <tr>
                            <th width="5%" class="text-center">#Bil</th>
                            <th width="35%">Projek</th>
                            <th width="10%" class="text-center">Kod Subsetia</th>
                            <th class="text-right" width="10%">Kos Yang Diluluskan</th>
                            <th width="5%" class="text-center">Pilih</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if($projek->count()>0)
                            @php
                                $bil=1;
                            @endphp
                            @foreach ($projek as $proj)
                                <tr>
                                    <td class="text-center">{{ $bil++ }}</td>
                                    <td>{!! $proj->proj_nama !!}</td>
                                    <td class="text-center">{{ $proj->proj_kod_subsetia }}</td>
                                    <td class="text-right">@duit($proj->proj_kos_sebenar)</td>
                                    <td class="text-center">
                                        <div><label><input name="projekSediaAda" id="{{ $proj->projek_id }}" type="radio" value="{{ $proj->projek_id }}"></label></div>
                                    </td>
                                </tr>
                            @endforeach
                        @else
                            <tr>
                                <td colspan="5" class="font-italic text-small text-center">Tiada Rekod</td>
                            </tr>
                        @endif
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="8">
                                <ul class="pagination float-right"></ul>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="ibox">
            <div class="ibox-title">
                <h5>2. MAKLUMAT AKTIVITI PENYELENGGARAAN</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                    <a class="close-link">
                        <i class="fa fa-times"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <div class="row">
                    <div class="col-6">
                        <div class="i-checks">
                            <label><input type="radio" value="2" name="jenisKegunaan" id="jenisKegunaan2"> Tukar Tajuk / Skop</label>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="i-checks">
                            <label><input type="radio" value="1" name="jenisKegunaan" id="jenisKegunaan1"> Kenaikan Kos </label>
                        </div>
                    </div>
                </div>
                <div id="detailSelenggara" style="display: none">
                    <small class="tetx-muted">* Sila masukkan maklumat Nama / Skop / Justifikasi Projek yang ingin diselenggara. Kosongkan jika tiada perubahan pada.</small>
                    <br><br>
                    <div class="form-group">
                        <label>Nama Projek Baharu</label>
                        {{ Form::textarea('proj_nama_baru', null, ['class'=>'form-control', 'id'=>'proj_nama_baru', 'rows'=>'3']) }}
                        @error('proj_nama')
                            <span class="text-danger">{{ $message}}</span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label>Skop Projek Baharu</label>
                        {{ Form::textarea('proj_skop_baru', null, ['class'=>'form-control', 'id'=>'proj_skop_baru', 'rows'=>'3']) }}
                        @error('proj_skop')
                            <span class="text-danger">{{ $message}}</span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label>Justifikasi Projek Baharu</label>
                        {{ Form::textarea('proj_justifikasi_baru', null, ['class'=>'form-control', 'id'=>'proj_justifikasi_baru', 'rows'=>'3']) }}
                        @error('proj_justifikasi')
                            <span class="text-danger">{{ $message}}</span>
                        @enderror
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="ibox">
            <div class="ibox-title">
                <h5>3. MAKLUMAT SUMBER KEWANGAN</h5>
                <div class="ibox-tools">
                    <strong>JUMLAH PENJIMATAN : RM @duit($jumlah)</strong>
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                    <a class="close-link">
                        <i class="fa fa-times"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <input type="text" class="form-control form-control-sm m-b-xs" id="filter" placeholder="Cari projek">
                <table class="footable table table-stripped" data-page-size="10" data-filter=#filter>
                    <thead>
                        <tr>
                            <th width="5%" class="text-center">#Bil</th>
                            <th width="35%">Projek</th>
                            <th width="10%" class="text-center">Kuasa KJ</th>
                            <th width="10%" class="text-center">Kod Subsetia</th>
                            <th width="15%" class="text-center">Kategori</th>
                            <th class="text-right" width="10%">Penjimatan</th>
                            <th width="5%" class="text-center">Pilih</th>
                            <th width="10%" class="text-center">#</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if($bakulJimat->count()>0)
                            @php
                                $bil=1;
                            @endphp
                            @foreach ($bakulJimat as $item)
                                <tr>
                                    <td class="text-center">{{ $bil++ }}</td>
                                    <td>{!! $item->bj_title !!}</td>
                                    <td class="text-center">
                                        @if ($item->bj_kuasa_pkn==1)
                                            <i class="fa fa-check text-navy"></i>
                                        @else
                                        <i class="fa fa-close text-danger"></i>
                                        @endif

                                    </td>
                                    <td class="text-center">{{ $item->bj_subsetia }}</td>
                                    <td class="text-center">
                                        @php
                                        if($item->bj_kategori == 1)
                                            echo '<span class="badge badge-primary">'.getStatusJimat($item->bj_kategori).'</span>';
                                        elseif($item->bj_kategori == 2)
                                            echo '<span class="badge badge-info">'.getStatusJimat($item->bj_kategori).'</span>';
                                        elseif($item->bj_kategori == 3)
                                                echo '<span class="badge badge-danger">'.getStatusJimat($item->bj_kategori).'</span>';
                                        else
                                                echo '<span class="badge badge-warning">'.getStatusJimat($item->bj_kategori).'</span>';
                                        @endphp
                                    </td>
                                    <td class="text-right">@duit($item->bj_amount_jimat)</td>
                                    <td class="text-center">
                                        <div><label><input name="sumberKewangan[]" class="pilihJimat" id="{{ $item->bakul_jimat_id }}" type="checkbox" value="{{ $item->bj_projek_id.'-'.$item->bj_amount_jimat.'-'.$item->bj_subsetia.'-'.$item->bj_kategori.'-'.$item->bj_kuasa_pkn.'-'.$item->bakul_jimat_id }}"></label></div>
                                    </td>
                                    <td class="text-center">
                                        <button type="button" value="{{ $item->bakul_jimat_id }}" class="btn btn-default btn-xs updateBakul" title="Kemaskini"><i class="fa fa-pencil text-navy"></i></button>
                                        <button type="button" value="{{ $item->bakul_jimat_id }}" class="btn btn-default btn-xs delBakul" title="Padam"><i class="fa fa-trash text-danger"></i></button>
                                    </td>
                                </tr>
                            @endforeach
                            <tr>
                                <td colspan="6" class="text-danger text-right"><small>
                                    Dengan ini saya mengesahkan penyelengaraan maklumat projek ini tidak melibatkan sebarang pertambahan atau pengurangan kos sedia ada.
                                </small>
                                </td>
                                <td class="text-center">
                                    <input id="acceptNoCosting" name="acceptNoCosting" type="checkbox" value="1" class="required">
                                </td>
                                <td></td>
                            </tr>
                        @else
                            <tr>
                                <td colspan="8" class="font-italic text-small text-center">Tiada Rekod</td>
                            </tr>
                        @endif
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="8">
                                <ul class="pagination float-right"></ul>
                            </td>
                        </tr>
                    </tfoot>
                </table>

                <div class="hr-line-dashed"></div>
                <div class="row">
                    <div class="col-9">
                        <small class="tetx-muted">* Penggabungan projek hanya dibenarkan kepada projek yang memiliki kod subsetia.</small>
                    </div>
                    <div class="col-1 text-right">
                        JUMLAH :
                    </div>
                    <div class="col-2 ">
                        <div class="form-group">
                            <input type="text" name="jumSelect" id="jumSelect" class="form-control text-right" value="0.00" readonly>
                            @error('jumSelect')
                                <span class="text-danger">{{ $message}}</span>
                            @enderror
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-12">
        <div class="ibox">
            <div class="ibox-title">
                <h5>4. PENGESAHAN DAN PERAKUAN</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                    <a class="close-link">
                        <i class="fa fa-times"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">
                <fieldset>
                    <input id="acceptTerms" name="acceptTerms" type="checkbox" class="required"> <label for="acceptTerms">Dengan ini saya mengesahkan bahawa permohonan ini telah disahkan dan diperakukan oleh Ketua Jabatan.</label>
                </fieldset>
            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="ibox-content">
            <div class="form-group row">
                <div class="col-sm-4 col-sm-offset-2">
                    <a href="/permohonan/baru/senarai" class="btn btn-white btn-sm">Batal</a>
                    <button class="btn btn-primary btn-sm float-end" type="submit">Simpan</button>
                    {{-- <button class="btn btn-info btn-sm" type="submit">Simpan dan Salin</button> --}}
                </div>
            </div>
        </div>
    </div>
</div>
</form>
@include('app/guna-baki/_modal/update_bakul')
@endsection
@section('custom-js')
<!-- Date picker -->
<script src="{{ asset("/template/js/plugins/datapicker/bootstrap-datepicker.js") }}"></script>
<!-- Select2 -->
<script src="{{ asset("/template/js/plugins/select2/select2.full.min.js") }}"></script>
<script src="{{ asset('/template/js/plugins/footable/footable.all.min.js') }}"></script>
<script>
    $(document).ready(function(){
        let amount = 0;
        let currSubS='';
        let currType='';
        let currPKN='';

        $('.footable').footable();
        $('.footable2').footable();


        $('.pilihJimat').change(function(){
            pjVal = $(this).val();
            bjArray = pjVal.split("-");
            if($(this).prop("checked")){
                // CEK SUBSETIA
                if(currSubS==''){
                    currSubS = bjArray[2];
                    amount += Number(bjArray[1]);
                }
                else{
                    if(currSubS!=bjArray[2]){
                        swal("Kod Subsetia", "Sila pilih kod subsetia yang sama sahaja", "error");
                        $(this).prop("checked", false);
                        currSubS='';
                        currType='';
                        currPKN='';
                    }
                    else{
                       amount += Number(bjArray[1]);
                    }

                }

                // CEK KATEGORI
                // if(currType==''){
                //     currType=bjArray[3];
                //     // Set pilhan kategori
                //     // 1-Penjimatan, 2-Tukar Tajuk; 3
                //     if(currType==1){
                //         $('#pilihKategori').html('Kenaikan Kos');
                //         $('#katSelenggara').val(currType);
                //     }
                //     else{
                //         $('#pilihKategori').html('Tukar Tajuk / Skop');
                //         $('#detailSelenggara').show();
                //         $('#katSelenggara').val(currType);
                //     }
                // }
                // else{
                //     if(currType!=bjArray[3]){
                //         swal("Kategori ", "Sila pilih dalam kategori yang sama sahaja", "error");
                //         $(this).prop("checked", false);
                //         amount -= Number(bjArray[1]);
                //         currSubS='';
                //         currType='';
                //         currPKN='';
                //     }
                // }

                // CEK PKN
                if(currPKN==''){
                    currPKN=bjArray[4];
                    $('#proj_kuasa_pkn').val(currPKN);
                }
                else{
                    if(currPKN!=bjArray[4]){
                        swal("Kuasa PKN ", "Sila pilih punca kuasa yang sama sahaja", "error");
                        $(this).prop("checked", false);
                        amount -= Number(bjArray[1]);
                        currSubS='';
                        currType='';
                        currPKN='';
                    }
                }

            }
            else{
                amount -= Number(bjArray[1]);
            }
            $('#proj_kod_subsetia').val(currSubS);
            $('#jumSelect').val(parseFloat(amount).toFixed(2));
        });

        $('input[name="jenisKegunaan"]').on('change', function(){
            jnsGuna = $('input[name="jenisKegunaan"]:checked').val();
            if(jnsGuna==1){
                $('#detailSelenggara').hide();
            }
            else{
                $('#detailSelenggara').show();
            }
        });

        function financial(x) {
            return Number.parseFloat(x).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        }

        $('#data_1 .input-group.date').datepicker({
            todayBtn: "linked",
            format: "dd/mm/yyyy",
            keyboardNavigation: false,
            forceParse: false,
            // calendarWeeks: true,
            autoclose: true
        });
        $('#data_2 .input-group.date').datepicker({
            todayBtn: "linked",
            format: "dd/mm/yyyy",
            keyboardNavigation: false,
            forceParse: false,
            // calendarWeeks: true,
            autoclose: true
        });
        //ON CHANGE NEGERI DROPDOWN EVENT
        $('#proj_negeri').on('change', function() {
            var parID = $(this).val();
            getFasiliti(parID, 'proj_daerah', '#list-daerah');
            // getFasiliti(cariNegeri, 'proj_fasiliti_id', '#list-fasiliti');
        });

        $('#proj_laksana_mula').on('change', function(){
            var selDate = $(this).val();
            var spilDate = selDate.split('/');
            $('#proj_bulan').val(getMonth(spilDate[1]));
            $('#proj_tahun').val(spilDate[2])
            // alert(spilDate[0]);
        });


        //ADD BUTTON CLICK
        $('#add').click(function(e){
            e.preventDefault();
            $('#addModal').modal('show');
        });

        $('#addUnjuran').click(function(e){
            e.preventDefault();
            $('#addKewangan').modal('show');
        });

        $('#proj_pelaksana').on('change', function(){
            let select = $(this).val();

            if(select == 3){
                $('#pilihJkr').show();
            }
            else{
                $('#pilihJkr').hide();
            }
        });

        $('.custom-file-input').on('change', function() {
            let fileName = $(this).val().split('\\').pop();
            $(this).next('.custom-file-label').addClass("selected").html(fileName);
        });

        //GET DAERAH DROPDOWN HTML AJAXCONTROLLER
        function getFasiliti(parID='0', inputname='0', list='0', select='99') {
            let url = "/ajax/ajax-daerah/" + parID + "/" + inputname + "/" + select;
            $.get(url, function(data) {
                $(list).html(data);
                $('#proj_daerah').on('change', function() {
                    var daerahID = $(this).val();
                    var list = '#list-fasiliti';
                    var inputname = 'proj_fasiliti_id';
                    let url = "/ajax/ajax-fasiliti/" + daerahID + "/" + inputname + "/" + select;
                    $.get(url, function(data) {
                        $(list).html(data);
                        // $('#proj_fasiliti_id').on('change', function() {});
                        // alert('AA');
                        $('#proj_parlimen').val('P02 - Tiada Rekod');
                        $('#proj_dun').val('N22 - Tiada Rekod');
                    });
                });
            });
        }

        function getMonth(month){
            let bulan={
                '01': 'Januari',
                '02': 'Februari',
                '03': 'Mac',
                '04': 'April',
                '05': 'Mei',
                '06': 'Jun',
                '07': 'Julai',
                '08': 'Ogos',
                '09': 'September',
                '10': 'Oktober',
                '11': 'November',
                '12': 'Disember'
            };

            return bulan[month];

        }

        $('form').on('submit', function() {
            // let acceptNoCosting=0;
            let selAmaun = $('#jumSelect').val();
            let checked = $('input[name="acceptTerms"]:checked').length;
            let sediaAda = $('input[name="projekSediaAda"]:checked').length;
            let jnsGuna = $('input[name="jenisKegunaan"]:checked').length;
            let namaBaru = $('#proj_nama_baru').val();
            let skopBaru = $('#proj_skop_baru').val();
            let justifikasiBaru = $('#proj_justifikasi_baru').val();
            // let acceptNoCosting = $('input[name="acceptNoCosting"]:checked').length;
            let acceptNoCosting = $('input[name="acceptNoCosting"]:checked').length;
            let jnsGunaVal = $('input[name="jenisKegunaan"]:checked').val();

            // alert(jnsGunaVal);
            if (sediaAda == 0) {
                swal("Projek Sedia Ada", "Sila Pilih Projek Sedia Ada", "error");
                return false;
            }

            if(jnsGuna == 0) {
                swal("Aktiviti Penyelenggaraan", "Sila Pilih Jenis Aktiviti Penyelenggaraan", "error");
                return false;
            }

            if(jnsGunaVal==2){
                if (namaBaru =='' && skopBaru =='' && justifikasiBaru ==''){
                    swal("Selenggara Projek", "Sila masukkan maklumat perubahan Nama / Skop / Justifikasi Projek", "error");
                    return false;
                }
            }

            if(acceptNoCosting ==0){
                if (selAmaun == 0.00) {
                    swal("Sumber Kewangan", "Sila pilih sumber kewangan", "error");
                    return false;
                }
            }

            if (checked == 0) {
                swal("Pengesahan", "Sila sahkan pengesahan Ketua Jabatan", "error");
                return false;
            }
            return true;
            // alert('OK');

        });

    });

    $(document).on('click', '.updateBakul', function () {
        let jimatID = $(this).val();
        $('#addModal').modal('show');
        $.ajax({
            type: "GET",
            url: "/projek/penjimatan/ubah/" + jimatID,
            success: function (response) {
                if (response.status == 404){
                    $('#addModal').modal('hide');
                    swal({
                        title: "Maklumat Penjimatan",
                        text: response.message,
                        type: "danger"
                    });
                } else {
                    $('#bakul_jimat_id').val(response.jimat.bakul_jimat_id);
                    $('#bj_title').val(response.jimat.bj_title);
                    $('#bj_subsetia').val(response.jimat.bj_subsetia);
                    $('#bj_kategori').val(response.jimat.bj_kategori);
                    $('#bj_amount_jimat').val(response.jimat.bj_amount_jimat);
                    $('#bj_status').val(response.jimat.bj_status);
                }
            }
        });
    });

    $(document).on('click', '.ubahJimat', function (e) {
        $('#addModal').modal('show');
        e.preventDefault();
        var edit_data = {
            'bakul_jimat_id': $('#bakul_jimat_id').val(),
            'bj_title': $('#bj_title').val(),
            'bj_subsetia': $('#bj_subsetia').val(),
            'bj_kategori': $('#bj_kategori').val(),
            'bj_amount_jimat': $('#bj_amount_jimat').val(),
            'bj_status': $('#bj_status').val(),
        }
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url: "/projek/penjimatan/kemaskini",
            data: edit_data,
            dataType: "json",
            success: function (response) {
                if (response.status == 400) {
                    $('#update_msgList').html("");
                    $('#update_msgList').addClass('alert alert-danger');
                    $.each(response.errors, function (key, err_value) {
                        $('#update_msgList').append('<li>' + err_value +
                            '</li>');
                    });
                } else {
                    $('#update_msgList').html("");
                    $('#addModal').find('input').val('');
                    $('#addModal').find('textarea').val('');
                    $('#addModal').modal('hide');
                    location.reload(true);
                }
            }
        });
    });

    $(document).on('click', '.delBakul', function () {
        let delID = $(this).val();
        swal({
            title: "Adakah anda pasti?",
            text: "Sila pastikan rekod yang hendak dipadam",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Ya, Padam",
            cancelButtonText: "Tidak, Batalkan",
            closeOnConfirm: false,
            closeOnCancel: false
        },
        function (isConfirm) {
            if (isConfirm) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    type: "get",
                    url: "/projek/penjimatan/padam/" + delID,
                    dataType: "json",
                    success: function (response) {
                        if (response.status == 404) {
                            swal("Dibatalkan", response.message, "error");
                        } else {
                            location.reload(true);
                        }
                    }
                });
            } else {
                swal("Dibatalkan", "Rekod penjimatan tidak dipadam", "error");
            }
        });
    });
</script>

@endsection

<!DOCTYPE html>
<html>
<head>
    <title>Sistem eDE</title>
</head>
<body>
    <p>Assalammualaikum dan salam sejahtera,</p><br>
    <p>YBhg. Datuk / YBhg. Dato'. / YBrs. Dr./ Tuan / Puan, <br></p>
    <h3>PEMAKLUMAN AKTIVITI TUKAR TAJUK PROJEK OLEH {{ strtoupper($projPemilik) }}</h3>
    <p>
        Unit Bajet RMK, Bahagian Pembangunan mengambil maklum bahawa, <strong>{{ $projPemilik }}</strong> telah melakukan aktiviti pertukaran tajuk projek : <strong>{{ $projTitleAsal }}</strong> kepada tajuk baharu : <strong>{{ $projTitleBaru }}</strong>.<br><br><br>
        Sekian, terima kasih.<br><br>
        <strong>“MALAYSIA MADANI”</strong><br><br>
        <strong>“BERKHIDMAT UNTUK NEGARA”</strong><br><br><br>
        Saya yang menjalankan amanah,<br>
        BAHAGIAN PEMBANGUNAN<br>
        KEMENTERIAN KESIHATAN MALAYSIA
    </p><br>
    <p><i><small>E-mel ini adalah janaan komputer. Tiada sebarang maklum balas diperlukan</small></i></p>
</body>
</html>

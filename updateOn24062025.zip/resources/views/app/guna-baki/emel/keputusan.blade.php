<!DOCTYPE html>
<html>
<head>
    <title>Sistem eDE</title>
</head>
<body>
    <p>Assalammualaikum dan salam sejahtera,</p><br>
    <p>YBhg. Datuk Dr./YBhg. Dato' Dr./YBrs. Dr./Tuan/Puan, <br></p>
    <h3>PEMAKLUMAN KELULUSAN PERMOHONAN GUNA BAKI</h3>
    <p>
        Sukacita dimaklumkan bahawa Bahagian Pembangunan telah <strong>MELULUSKAN</strong> permohonan guna baki<br><br>
        Sehubungan dengan itu, pihak YBhg. Datuk Dr./YBhg. Dato’ Dr./YBrs. Dr./Tuan/Puan dikehendaki melaksanakan proses perolehan dengan kadar segera.<br><br><br>
        Sekian, terima kasih.<br><br>
        <strong>“MALAYSIA MADANI”</strong><br><br>
        <strong>“BERKHIDMAT UNTUK NEGARA”</strong><br><br><br>
        Saya yang menjalankan amanah,<br>
        BAHAGIAN PEMBANGUNAN<br>
        KEMENTERIAN KESIHATAN MALAYSIA
    </p><br>
    <p><i><small>E-mel ini adalah janaan komputer. Tiada sebarang maklum balas diperlukan</small></i></p>
</body>
</html>

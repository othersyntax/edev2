<!DOCTYPE html>
<html>
<head>
    <title>Sistem eDE</title>
</head>
<body>
    <p>Assalammualaikum dan salam sejahtera,</p><br>
    <p>Tuan/Puan, <br></p>
    <h3>PEMAKLUMAN PERMOHONAN GUNA BAKI OLEH PEMILIK PROJEK</h3>
    <p>
        Sukacita dimaklumkan bahawa terdapat satu permohonan projek baharu dengan menggunakan baki penjimatan telah dibuat oleh pemilik projek. Sila ambil tindakan melalui sistem eDE.<br><br><br>
        Sekian, terima kasih.<br><br>
        <strong>“MALAYSIA MADANI”</strong><br><br>
        <strong>“BERKHIDMAT UNTUK NEGARA”</strong><br><br><br>
        Saya yang menjalankan amanah,<br><br>
        <strong>UNIT BAJEK RMK</strong><br>
        BAHAGIAN PEMBANGUNAN<br>
        KEMENTERIAN KESIHATAN MALAYSIA
    </p><br>
    <p><i><small>E-mel ini adalah janaan komputer. Tiada sebarang maklum balas diperlukan</small></i></p>
</body>
</html>

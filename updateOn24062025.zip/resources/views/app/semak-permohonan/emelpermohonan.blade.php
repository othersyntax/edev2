<!DOCTYPE html>
<html>
<head>
    <title>Sistem eDE</title>
</head>
<body>
    <p>Assalammualaikum dan salam sejahtera,</p><br>
    <p>Dato' / Dr. / Tuan / Puan, <br></p>
    <h3>PEMAKLUMAN PENETAPAN SILING BAGI PERUNTUKAN BP00600</h3>
    <p>
        Sukacita dimaklumkan bahawa, Unit Bajet RMK Bahagian Pembangunan telah menetap siling bagi belanja pembangunan BP00600 tahun 2025.<br><br>
        2.  Oleh yang demikian, YBhg. Dato' / Dr. / Tuan / Puan boleh mengunci masuk maklumat projek bagi tahun 2025 ke dalam siste eDE sebelum tarikh tamat yang telah ditetap.<br><br>
        3.  Sekiranya YBhg. Dato' / Dr. / Tuan / Puan mempunya sebarang pertanya mengenai perkara ini, YBhg. Dato' / Dr. / Tuan / Puan boleh berhubung dengan Unit Bajet RMK Bahagian Pembangunan ditalian 03-88832021.<br><br>
        4.  Kerjasama dan perhatian YBhg. Dato' / Dr. / Tuan / Puan dalam perkara ini amatlah dihargai.<br><br><br>
        Sekian, terima kasih.<br><br>
        <strong>“MALAYSIA MADANI”</strong><br><br><br>
        <strong>“BERKHIDMAT UNTUK NEGARA”</strong><br><br><br>
        Saya yang menjalankan amanah,
    </p><br>
    <p><i><small>Emel ini adalah janaan komputer. Jangan balas emel ini</small></i></p>
</body>
</html>

<div class="modal inmodal" id="ModalEditStatus" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content animated bounceInRight">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                {{-- <i class="fa fa-cogs modal-icon"></i> --}}
                <h4 class="modal-title">Kemaskini Status Projek</h4>
                <small class="font-bold">Sila pilih status semasa bagi projek ini</small>
                {{-- <h5>Anggaran Kos (RM) : RM 1,500,000.00</h5> --}}
            </div>
            <div class="modal-body">
                <div class="col-lg-12">
                    <ul id="save_msgList_peruntukan2"></ul>
                </div>
                <input type="hidden" id="projekStatus_id2">
                <div class="form-group">
                    <label>Sila pilih status semasa projek:</label>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">Batal</button>
                <button type="button" class="btn btn-primary addPeruntukan">Simpan</button>
            </div>
        </div>
    </div>
</div>

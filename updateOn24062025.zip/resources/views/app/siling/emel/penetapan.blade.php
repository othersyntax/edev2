<!DOCTYPE html>
<html>
<head>
    <title>Sistem eDE</title>
</head>
<body>
    <p>Assalammualaikum dan salam sejahtera,</p><br>
    <p>YBhg. Datuk Dr./YBhg. Dato' Dr./YBrs. Dr./Tuan/Puan,<br></p>
    <h3>PEMAKLUMAN PENETAPAN SILING BAGI PERUNTUKAN BP00600</h3>
    <p>
        Sukacita dimaklumkan bahawa Unit Bajet RMK, Bahagian Pembangunan telah membuat penetapan siling bagi peruntukan pembangunan BP00600 tahun 2025.<br><br>
        2.  Oleh yang demikian, YBhg. Datuk Dr./YBhg. Dato' Dr./YBrs. Dr./Tuan/Puan boleh mengunci masuk senarai dan maklumat projek bagi tahun 2025 dalam sistem eDE sebelum tarikh tamat yang ditetapkan.<br><br>
        3.  Sebarang pertanyaan mengenai perkara ini, boleh menghubungi Unit Bajet RMK, Bahagian Pembangunan di talian 03-88832026/03-88832058/03-88832024.<br><br><br>
        Sekian, terima kasih.<br><br>
        <strong>“MALAYSIA MADANI”</strong><br><br><br>
        <strong>“BERKHIDMAT UNTUK NEGARA”</strong><br><br><br>
        Saya yang menjalankan amanah,<br><br>
        UNIT BAJEK RMK<br>
        BAHAGIAN PEMBANGUNAN<br>
        KEMENTERIAN KESIHATAN MALAYSIA
    </p><br>
    <p><i><small>E-mel ini adalah janaan komputer. Tiada sebarang maklum balas diperlukan</small></i></p></body>
</html>

<!DOCTYPE html>
<html>
<head>
    <title>Laravel Mail</title>
</head>
<body>
    <h1>Emel eDE</h1>
    <p>Assalammualaikum dan salam sejahtera, in adalah kandungan emel</p>
    <p>Thank you</p>
</body>
</html>

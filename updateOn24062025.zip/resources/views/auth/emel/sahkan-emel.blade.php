<!DOCTYPE html>
<html>
<head>
    <title>Sistem eDE</title>
</head>
<body>
    <p>Assalammualaikum dan salam sejahtera,</p>
    <p>YBhg. Datuk Dr./YBhg. Dato' Dr./YBrs. Dr./Tuan/Puan : <strong>{{ $user->name }}</strong></p><br><br>
    <h3>PEMAKLUMAN PEMBUKAAN AKAUN BAHARU</h3>
    <p>

        Untuk membuat verifikasi e-mel,YBhg. Datuk Dr./YBhg. Dato' Dr./YBrs. Dr./Tuan/Puan adalah dimohon untuk menekan butang <strong>Sahkan E-Mel Saya</strong> seperti yang berikut:<br><br>

        <a href="{{ $url }}" style="background-color: blue; color:white; padding:10px 20px; text-decoration: none;">Sahkan E-Mel Saya</a><br><br>
        Kerjasama dan perhatian YBhg. Datuk Dr./YBhg. Dato' Dr./YBrs. Dr./Tuan/Puan dalam perkara ini adalah dihargai.

        Sekian, terima kasih.<br><br>
        <strong>“MALAYSIA MADANI”</strong><br><br>
        <strong>“BERKHIDMAT UNTUK NEGARA”</strong><br><br><br>
        Saya yang menjalankan amanah,<br><br>
        UNIT BAJEK RMK<br>
        BAHAGIAN PEMBANGUNAN<br>
        KEMENTERIAN KESIHATAN MALAYSIA
    </p><br>
    <p><i><small>E-mel ini adalah janaan komputer. Jangan balas e-mel ini</small></i></p>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <title>Sistem eDE</title>
</head>
<body>
    <p>Assalammualaikum dan salam sejahtera,</p>
    <p>YBhg. Datuk Dr../YBhg. Dato'./YBrs. Dr./Tuan/Puan, <br></p>
    <h3>PEMAKLUMAN PEMBUKAAN AKAUN BARU</h3>
    <p>
        Adalah dimaklumkan bahawa maklumat akaun anda telah berjaya didaftarkan di dalam Sistem Pengurusan Peruntukan Pembangunan. Maklumat pendaftaran adalah seperti berikut:<br><br>

        {{-- Nama        : {{$user->name}}<br><br> --}}
        Kementerian : KEMENTERIAN KESIHATAN MALAYSIA<br>
        {{-- Organisasi  : <br><br> --}}
        Login Id    : Emel Rasmi<br>
        Kata Laluan : eDE@2024<br>
        Capaian     : http://ede.moh.gov.my<br><br>

        Sekian, terima kasih.<br><br>
        <strong>“MALAYSIA MADANI”</strong><br><br>
        <strong>“BERKHIDMAT UNTUK NEGARA”</strong><br><br><br>
        Saya yang menjalankan amanah,<br><br>
        UNIT BAJEK RMK<br>
        BAHAGIAN PEMBANGUNAN<br>
        KEMENTERIAN KESIHATAN MALAYSIA
    </p><br>
    <p><i><small>Emel ini adalah janaan komputer. Jangan balas emel ini</small></i></p>
</body>
</html>

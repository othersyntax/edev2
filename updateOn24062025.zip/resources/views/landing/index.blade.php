@extends('layouts.landing')
@section('content')
    
@endsection
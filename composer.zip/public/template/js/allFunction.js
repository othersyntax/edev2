function getStatus(id){

    if(id==1)
        return "Aktif";
    else
        return "Tidak Aktif";
}
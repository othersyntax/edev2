<?php

return [
    '01'=> 'Januari',
    '02'=> 'Februari',
    '03'=> 'Mac',
    '04'=> 'April',
    '05'=> 'Mei',
    '06'=> 'Jun',
    '07'=> 'Julai',
    '08'=> 'Ogos',
    '09'=> 'September',
    '10'=> 'Oktober',
    '11'=> 'November',
    '12'=> 'Disember'
];
